Step 1:
   create basic fetch and renderProducts


Step 2:
   add login & single product view


Step 3:
   1. script.js
      1. Reorganize function positions +
      2. Create products container inside renderProducts function
      3. Add try catch inside fetchProducts
      4. Container -> Display flex
      5. Add .product class to each product (flex-grow)
      6. https://codepen.io/pen/
      7. Add stars into one div(starsContainer)
   2. Create separate “stylesheets” folder
   3. Create separate “scripts” folder


Step 4:
   1. CRUD (create read update delete)
   2. Password toggle ✅
   3. Login button spinner 
   4. Toggle button not working in the start ✅
   5. Separate sass _partials ✅
   6. Add aside (https://www.figma.com/design/bE1KisjUbUF3dfBkKxWX9L/GameGeek-(Community)?node-id=187-2254&t=S7AvCaI6iQGC8ZhI-0)
      1. My account
      2. Personal information
      3. My orders
      4. Support
      5. Just for you

